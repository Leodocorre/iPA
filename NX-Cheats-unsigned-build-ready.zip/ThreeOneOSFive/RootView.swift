import SwiftUI

struct RootView: View {
    @EnvironmentObject private var licenseSession: LicenseSession

    var body: some View {
        Group {
            switch licenseSession.state {
            case .unlocked:
                ContentView()
            case .checking:
                ZStack {
                    Color.black.ignoresSafeArea()
                    ProgressView("Validando licença…")
                        .tint(AppTheme.accent)
                        .foregroundStyle(.white)
                }
            case .locked, .error:
                KeyGateView()
            }
        }
        .task {
            await licenseSession.restoreSession()
        }
    }
}
