import Foundation

struct LicenseService {
    static let shared = LicenseService()

    private let baseURL = URL(string: "https://nxcheatslp-qgtjne7m.manus.space")!
    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()

    func activate(key: String, installationID: String, appVersion: String) async throws -> LicenseActivationResponse {
        let payload = LicenseActivationRequest(
            key: key,
            installation_id: installationID,
            app_version: appVersion
        )
        return try await send(path: "/api/license/activate", payload: payload, token: nil)
    }

    func check(sessionToken: String, installationID: String) async throws -> LicenseCheckResponse {
        let payload = LicenseCheckRequest(
            session_token: sessionToken,
            installation_id: installationID
        )
        return try await send(path: "/api/license/check", payload: payload, token: sessionToken)
    }

    func deactivate(sessionToken: String, installationID: String) async throws -> LicenseDeactivationResponse {
        let payload = LicenseCheckRequest(
            session_token: sessionToken,
            installation_id: installationID
        )
        return try await send(path: "/api/license/deactivate-device", payload: payload, token: sessionToken)
    }

    private func send<Request: Encodable, Response: Decodable>(path: String, payload: Request, token: String?) async throws -> Response {
        let endpoint = baseURL.appendingPathComponent(path.trimmingCharacters(in: CharacterSet(charactersIn: "/")))
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let token {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        request.httpBody = try encoder.encode(payload)

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse else {
            throw LicenseServiceError.invalidResponse
        }
        guard (200..<300).contains(httpResponse.statusCode) else {
            throw LicenseServiceError.forStatusCode(httpResponse.statusCode)
        }

        do {
            return try decoder.decode(Response.self, from: data)
        } catch {
            throw LicenseServiceError.invalidResponse
        }
    }
}

private struct LicenseActivationRequest: Encodable {
    let key: String
    let installation_id: String
    let app_version: String
}

private struct LicenseCheckRequest: Encodable {
    let session_token: String
    let installation_id: String
}

struct LicenseActivationResponse: Decodable {
    let success: Bool
    let session_token: String
    let status: String
    let first_used_at: String
    let expires_at: String
    let days_remaining: Int
}

struct LicenseCheckResponse: Decodable {
    let valid: Bool
    let status: String
    let first_used_at: String?
    let expires_at: String?
    let days_remaining: Int?
}

struct LicenseDeactivationResponse: Decodable {
    let success: Bool
}

enum LicenseServiceError: LocalizedError {
    case invalidResponse
    case forStatusCode(Int)

    var errorDescription: String? {
        switch self {
        case .invalidResponse:
            return "Não foi possível validar a licença. Tente novamente."
        case .forStatusCode(429):
            return "Muitas tentativas. Aguarde alguns minutos antes de tentar novamente."
        case .forStatusCode(503):
            return "O serviço de licenças está indisponível no momento."
        case .forStatusCode:
            return "Não foi possível ativar esta key."
        }
    }
}
