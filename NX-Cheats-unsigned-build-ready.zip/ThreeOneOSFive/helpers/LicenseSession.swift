import Foundation
import SwiftUI

enum LicenseSessionState: Equatable {
    case checking
    case locked
    case unlocked
    case error(String)
}

@MainActor
final class LicenseSession: ObservableObject {
    @Published private(set) var state: LicenseSessionState = .checking

    private let service: LicenseService

    init(service: LicenseService = .shared) {
        self.service = service
    }

    func restoreSession() async {
        guard let token = KeychainStore.sessionToken() else {
            state = .locked
            return
        }

        await validate(token: token)
    }

    func activate(key: String) async {
        guard Self.isValidKey(key) else {
            state = .error("Digite uma key no formato NX-Cheats-XXXXXXXX.")
            return
        }

        state = .checking
        do {
            let installationID = try KeychainStore.installationID()
            let response = try await service.activate(
                key: key,
                installationID: installationID,
                appVersion: Self.appVersion
            )
            guard response.success, response.status == "active" else {
                state = .locked
                return
            }
            try KeychainStore.saveSessionToken(response.session_token)
            state = .unlocked
        } catch {
            state = .error(error.localizedDescription)
        }
    }

    func deactivateCurrentDevice() async {
        guard let token = KeychainStore.sessionToken() else {
            state = .locked
            return
        }

        state = .checking
        do {
            let installationID = try KeychainStore.installationID()
            _ = try await service.deactivate(sessionToken: token, installationID: installationID)
            KeychainStore.removeSessionToken()
            state = .locked
        } catch {
            state = .error(error.localizedDescription)
        }
    }

    func retry() async {
        await restoreSession()
    }

    private func validate(token: String) async {
        state = .checking
        do {
            let installationID = try KeychainStore.installationID()
            let response = try await service.check(sessionToken: token, installationID: installationID)
            if response.valid, response.status == "active" {
                state = .unlocked
            } else {
                KeychainStore.removeSessionToken()
                state = .locked
            }
        } catch LicenseServiceError.forStatusCode(let statusCode) {
            if statusCode == 401 {
                KeychainStore.removeSessionToken()
                state = .locked
            } else {
                state = .error(LicenseServiceError.forStatusCode(statusCode).localizedDescription)
            }
        } catch {
            state = .error(error.localizedDescription)
        }
    }

    private static var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0.0"
    }

    private static func isValidKey(_ key: String) -> Bool {
        key.range(of: "^NX-Cheats-[A-HJ-NP-Z2-9]{8}$", options: .regularExpression) != nil
    }
}
