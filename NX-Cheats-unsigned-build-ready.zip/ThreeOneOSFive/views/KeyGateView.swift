import SwiftUI

struct KeyGateView: View {
    @EnvironmentObject private var licenseSession: LicenseSession
    @State private var key = ""

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.03, green: 0.08, blue: 0.13), Color(red: 0.04, green: 0.18, blue: 0.22)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 22) {
                Image(systemName: "key.horizontal.fill")
                    .font(.system(size: 36, weight: .semibold))
                    .foregroundStyle(AppTheme.accent)
                    .padding(18)
                    .background(.white.opacity(0.08), in: Circle())

                VStack(spacing: 8) {
                    Text("NX Cheats")
                        .font(.system(size: 30, weight: .bold, design: .rounded))
                    Text("Digite sua key de acesso para continuar.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }

                VStack(spacing: 14) {
                    TextField("NX-Cheats-XXXXXXXX", text: $key)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                        .textContentType(.oneTimeCode)
                        .font(.body.monospaced())
                        .padding(14)
                        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        .onChange(of: key) { value in
                            key = normalize(value)
                        }

                    if case let .error(message) = licenseSession.state {
                        Text(message)
                            .font(.footnote)
                            .foregroundStyle(.red)
                            .multilineTextAlignment(.center)
                    }

                    Button {
                        Task { await licenseSession.activate(key: key) }
                    } label: {
                        HStack(spacing: 8) {
                            if licenseSession.state == .checking {
                                ProgressView().tint(.white)
                            } else {
                                Image(systemName: "checkmark.shield.fill")
                            }
                            Text("Ativar key")
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(AppTheme.accent)
                    .disabled(key.isEmpty || licenseSession.state == .checking)
                }
                .frame(maxWidth: 420)

                Text("A validade é iniciada no primeiro uso válido.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(28)
        }
    }

    private func normalize(_ value: String) -> String {
        let trimmed = String(value.trimmingCharacters(in: .whitespacesAndNewlines).prefix(18))
        let lowercased = trimmed.lowercased()
        if lowercased.hasPrefix("nx-cheats-") {
            return "NX-Cheats-" + String(trimmed.dropFirst(10)).uppercased()
        }
        return trimmed
    }
}
