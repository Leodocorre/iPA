# Compilar a IPA do NX Cheats no Codemagic

O projeto está configurado para **`com.nxcheats.app`** e inclui o workflow `nx-cheats-ad-hoc` em `codemagic.yaml`. Ele usa um runner macOS na nuvem, aplica perfis de assinatura e exporta uma IPA Ad Hoc.

## Configuração de assinatura necessária

No Codemagic, crie uma integração Apple Developer com o nome **`nx-cheats-apple-key`**. Para isso, a conta Apple deve criar uma Team API Key no App Store Connect e informar o `Issuer ID`, `Key ID` e o arquivo privado `.p8` diretamente na área segura do Codemagic. Não inclua esse arquivo no repositório nem o envie por chat.

Na configuração de assinatura do aplicativo no Codemagic, selecione **Automatic**, escolha a integração criada, o tipo de perfil **Ad Hoc** e o Bundle ID **`com.nxcheats.app`**. Se o Bundle ID não aparecer, crie-o antes no Apple Developer Portal. Para instalar em dispositivos específicos fora do TestFlight, registre esses dispositivos no portal Apple antes de gerar o perfil Ad Hoc.

Após conectar o repositório ao Codemagic e reconhecer `codemagic.yaml`, execute o workflow **NX Cheats — IPA Ad Hoc**. Ao concluir, o serviço disponibilizará `build/ios/ipa/*.ipa` como artefato e enviará o link de download ao e-mail do iniciador.

Para TestFlight, altere `distribution_type` de `ad_hoc` para `app_store` e use o fluxo de publicação no App Store Connect.
