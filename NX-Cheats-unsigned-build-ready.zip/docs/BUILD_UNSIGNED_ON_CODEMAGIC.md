# Gerar uma IPA sem assinatura em nuvem

Este repositório inclui o workflow **NX Cheats — IPA sem assinatura** no arquivo `codemagic.yaml`. Ele não requer conta Apple Developer, certificado, perfil de provisionamento ou chave de API Apple.

## Passos

1. Crie uma conta gratuita no [Codemagic](https://codemagic.io/start) usando GitHub, GitLab ou Bitbucket.
2. Envie este projeto para um repositório privado no provedor escolhido. Nunca envie credenciais, certificados ou chaves da Apple ao repositório.
3. No Codemagic, escolha **Add application**, conecte o repositório e selecione o projeto iOS nativo.
4. Selecione a branch que contém `codemagic.yaml` e clique em **Check for configuration**.
5. Inicie o workflow **NX Cheats — IPA sem assinatura**.
6. Ao término, baixe o artefato `NX-Cheats-unsigned.ipa` na página da build ou pelo e-mail do iniciador.

## Limite do artefato

O arquivo gerado contém o aplicativo compilado, mas **não possui assinatura de código Apple**. Ele não é instalável diretamente no iPhone. A pessoa que o receber deverá re-assiná-lo usando um certificado e perfil de provisionamento próprios, compatíveis com `com.nxcheats.app`.

## Verificação prevista no workflow

O workflow arquiva o target `3105` para iPhone OS com `CODE_SIGNING_ALLOWED=NO`, verifica a presença de `3105.app` no archive e cria uma IPA padrão contendo `Payload/3105.app`.
