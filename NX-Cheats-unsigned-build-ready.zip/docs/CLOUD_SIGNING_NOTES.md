# Assinatura iOS em nuvem — notas verificadas

## Codemagic

O guia de aplicativos iOS nativos do Codemagic informa que a configuração deve residir em um arquivo `codemagic.yaml` na raiz do repositório. Para assinatura automática sem Mac próprio, a plataforma aceita uma integração com uma chave de API do App Store Connect e pode criar ou selecionar certificados e perfis de provisionamento correspondentes ao Bundle ID.

Para a integração, o usuário deve criar uma **Team API Key** no App Store Connect, baixar o arquivo privado `.p8` uma única vez e informar também `Issuer ID` e `Key ID`. A chave deve ser guardada como credencial segura, jamais enviada por chat ou adicionada ao repositório. Para gerar ou administrar certificados e perfis, a documentação recomenda uma chave com acesso **App Manager**.

No workflow, a assinatura deve indicar o Bundle ID `com.nxcheats.app` e um tipo de distribuição: `ad_hoc` para distribuição direta a dispositivos registrados ou `app_store` para TestFlight/App Store. O build nativo pode usar `xcode-project build-ipa --project "ThreeOneOSFive.xcodeproj" --scheme "3105"` e publicar os artefatos `build/ios/ipa/*.ipa`.

Fontes: [Codemagic — iOS native apps](https://docs.codemagic.io/yaml-quick-start/building-a-native-ios-app/); [Codemagic — iOS code signing](https://docs.codemagic.io/flutter-code-signing/ios-code-signing/).

## Apple

Segundo a Apple, Team API Keys podem acessar os endpoints de Provisioning; chaves individuais não podem. A chave privada `.p8` só pode ser baixada uma vez e deve ser tratada como credencial confidencial. A criação de Team API Key requer papel de administrador no App Store Connect.

Fonte: [Apple — Creating API Keys for App Store Connect API](https://developer.apple.com/documentation/appstoreconnectapi/creating-api-keys-for-app-store-connect-api).

## Alternativa GitHub Actions

O guia do GitHub para runners macOS requer uma combinação de certificado `.p12` com chave privada e perfil `.mobileprovision`, armazenados como GitHub Secrets, para assinar com `xcodebuild`. Isso normalmente exige preparar ou exportar os artefatos de assinatura antes do workflow, sendo menos adequado ao caso em que o usuário não possui Mac.

Fonte: [GitHub Docs — Installing an Apple certificate on macOS runners](https://docs.github.com/actions/use-cases-and-examples/deploying/installing-an-apple-certificate-on-macos-runners-for-xcode-development).
